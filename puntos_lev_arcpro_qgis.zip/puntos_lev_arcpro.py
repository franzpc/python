﻿# coding: utf-8
import arcpy
import numpy as np

## Dibujar los datos de un levantamiento topográfico a partir de un punto GPS
##Los puntos siguientes se midieron con cinta y brújula
##El resultado muestra los puntos con sus coordenadas XY en la tabla de atributos
## @franzpc
## Ajustar las direcciones del directorio

# Definir coordenadas del punto inicial
x_inicial = 722967
y_inicial = 9455080

# Definir el sistema de referencia
# WGS 1984 UTM Zone 17S = 32717 
# PSAD 1956 UTM Zone 17S = 24877
zona_utm = "17S"
sistema_referencia = arcpy.SpatialReference(24877)

# Crear nueva geodatabase y agregar feature class vacía
arcpy.CreateFileGDB_management("D:/SIG/tmp", "Puntos.gdb")
arcpy.CreateFeatureclass_management("D:/SIG/tmp/Puntos.gdb", "Puntos", "POINT", spatial_reference=sistema_referencia)

# Agregar campos de ID, distancia y ángulo
arcpy.AddField_management("D:/SIG/tmp/Puntos.gdb/Puntos", "ID", "LONG")
arcpy.AddField_management("D:/SIG/tmp/Puntos.gdb/Puntos", "Distancia", "DOUBLE")
arcpy.AddField_management("D:/SIG/tmp/Puntos.gdb/Puntos", "Angulo", "DOUBLE")
arcpy.AddField_management("D:/SIG/tmp/Puntos.gdb/Puntos", "Obs", "TEXT")

# Leer datos del archivo CSV
ruta_csv = "D:/SIG/tmp/puntos_lev.csv"
datos = np.genfromtxt(ruta_csv, delimiter=',', dtype=[('distancia', '<f8'), ('angulo', '<f8'), ('obs', '<U50')], skip_header=1)

# Calcular coordenadas UTM para cada punto y agregarlo a la feature class
cursor = arcpy.da.InsertCursor("D:/SIG/tmp/Puntos.gdb/Puntos", ["SHAPE@", "ID", "Distancia", "Angulo", "Obs"])
punto_inicial = arcpy.Point(x_inicial, y_inicial)
cursor.insertRow([punto_inicial, 0, 0, 0, ""])
id_punto = 1
x_anterior, y_anterior = x_inicial, y_inicial
for dato in datos:
    distancia = dato[0]
    angulo_grados = dato[1]
    obs = dato[2]
    angulo_radianes = np.radians(angulo_grados)
    x_actual = x_anterior + distancia * np.sin(angulo_radianes)
    y_actual = y_anterior + distancia * np.cos(angulo_radianes)
    punto = arcpy.Point(x_actual, y_actual)
    cursor.insertRow([punto, id_punto, distancia, angulo_grados, obs])
    id_punto += 1
    x_anterior, y_anterior = x_actual, y_actual
del cursor

# Calcular coordenadas XY en la tabla de atributos
arcpy.CalculateField_management("D:/SIG/tmp/Puntos.gdb/Puntos", "X", "!SHAPE!.centroid.X", "PYTHON3")
arcpy.CalculateField_management("D:/SIG/tmp/Puntos.gdb/Puntos", "Y", "!SHAPE!.centroid.Y", "PYTHON3")
# Crear un nuevo feature class de tipo Polyline
arcpy.CreateFeatureclass_management("D:/SIG/tmp/Puntos.gdb", "Segmentos", "POLYLINE", spatial_reference=sistema_referencia)

# Utilizar un cursor de búsqueda para recorrer los puntos y almacenarlos en una lista
puntos_list = []
with arcpy.da.SearchCursor("D:/SIG/tmp/Puntos.gdb/Puntos", ["SHAPE@"]) as cursor:
    for row in cursor:
        puntos_list.append(row[0].centroid)

# Crear y agregar segmentos individuales al feature class de tipo Polyline
with arcpy.da.InsertCursor("D:/SIG/tmp/Puntos.gdb/Segmentos", ["SHAPE@"]) as cursor:
    for i in range(len(puntos_list) - 1):
        punto1 = puntos_list[i]
        punto2 = puntos_list[i + 1]
        segmento = arcpy.Polyline(arcpy.Array([punto1, punto2]), sistema_referencia)
        cursor.insertRow([segmento])

# Calcular la longitud en metros de cada segmento
longitudes = []
with arcpy.da.SearchCursor("D:/SIG/tmp/Puntos.gdb/Segmentos", ["SHAPE@"]) as cursor:
    for row in cursor:
        longitud = row[0].length
        longitudes.append(longitud)

# Imprimir las longitudes de los segmentos
for i, longitud in enumerate(longitudes, 1):
    print(f"Longitud del segmento {i}: {longitud:.2f} metros")
