import os
import numpy as np
from qgis.core import (QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsField, QgsWkbTypes, QgsCoordinateReferenceSystem, QgsVectorFileWriter)

# Definir coordenadas del punto inicial
x_inicial = 722967
y_inicial = 9455080
zona_utm = "17S"
sistema_referencia = QgsCoordinateReferenceSystem("EPSG:24877")

# Crear una nueva capa de puntos
layer = QgsVectorLayer("Point?crs=EPSG:24877", "Puntos", "memory")

# Agregar campos de ID, distancia, ángulo, X y Y
layer.dataProvider().addAttributes([QgsField("ID", QVariant.Int),
                                    QgsField("Distancia", QVariant.Double),
                                    QgsField("Angulo", QVariant.Double),
                                    QgsField("X", QVariant.Double),
                                    QgsField("Y", QVariant.Double)])
layer.updateFields()

# Agregar la capa al proyecto
QgsProject.instance().addMapLayer(layer)

# Leer datos del archivo CSV
ruta_csv = "D:/SIG/tmp/puntos_lev.csv"
datos = np.genfromtxt(ruta_csv, delimiter=',', dtype=[('distancia', 'f8'), ('angulo', 'f8')], skip_header=1)

# Calcular coordenadas UTM para cada punto y agregarlo a la capa
punto_inicial = QgsPointXY(x_inicial, y_inicial)
feat_inicial = QgsFeature(layer.fields())
feat_inicial.setGeometry(QgsGeometry.fromPointXY(punto_inicial))
feat_inicial.setAttributes([0, 0, 0, x_inicial, y_inicial])

layer.startEditing()
layer.addFeatures([feat_inicial])

id_punto = 1
x_anterior, y_anterior = x_inicial, y_inicial
features = []
for dato in datos:
    distancia = float(dato[0])
    angulo_grados = float(dato[1])
    angulo_radianes = np.radians(angulo_grados)
    x_actual = x_anterior + distancia * np.sin(angulo_radianes)
    y_actual = y_anterior + distancia * np.cos(angulo_radianes)
    punto = QgsPointXY(x_actual, y_actual)
    feature = QgsFeature(layer.fields())
    feature.setGeometry(QgsGeometry.fromPointXY(punto))
    feature.setAttributes([id_punto, distancia, angulo_grados, x_actual, y_actual])
    features.append(feature)
    id_punto += 1
    x_anterior, y_anterior = x_actual, y_actual

layer.addFeatures(features)
layer.commitChanges()

# Calcular coordenadas XY
layer.startEditing()
for feature in layer.getFeatures():
    geom = feature.geometry()
    x, y = geom.asPoint().x(), geom.asPoint().y()
    layer.changeAttributeValue(feature.id(), layer.fields().indexFromName("X"), x)
    layer.changeAttributeValue(feature.id(), layer.fields().indexFromName("Y"), y)
layer.commitChanges()

# Guardar la capa de puntos en un archivo
ruta_salida = "D:/SIG/tmp/Puntos.gpkg"
options = QgsVectorFileWriter.SaveVectorOptions()
options.driverName = "GPKG"
options.layerName = "Puntos"
_writer, _ = QgsVectorFileWriter.writeAsVectorFormat(layer, ruta_salida, options)